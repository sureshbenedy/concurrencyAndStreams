package com.sample.listings.domain;


public class NamePhoneEmail {
	public String name;
	public String phonenum;
	public String email;

	public NamePhoneEmail(String n, String p, String e) {
		name = n;
		phonenum = p;
		email = e;
	}
}