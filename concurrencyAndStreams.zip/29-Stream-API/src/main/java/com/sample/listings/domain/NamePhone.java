package com.sample.listings.domain;


public class NamePhone {
	public String name;
	public String phonenum;

	public NamePhone(String n, String p) {
		name = n;
		phonenum = p;
	}
}